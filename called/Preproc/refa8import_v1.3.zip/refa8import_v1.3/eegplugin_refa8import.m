% eegplugin_refa8() - EEGLAB plugin for importimg REFA8 EEG rawdata (*.hdr,
% *.raw - QREFA - MPI CBS format)
% 
% Usage:
%   >> eegplugin_refa8import(fig,trystr,catchstr);
%
% Inputs:
%   fig       - [intereger] EEGLAB figure
%   trystr    - [struct] "try" strings for menu callbacks 
%   catchstr  - [struct] "catch" strings for menu callbacks
%
%
% Author:
%   Maren Grigutsch, MPI CBS Leipzig, May 2011
%
% See also: eeglab(), pop_loadrefa8()

% Copyrigh (C) 2011  Maren Grigutsch, MPI CBS Leipzig
%
%This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% $Id: eegplugin_refa8import.m,v 1.2 2017/11/28 17:31:05 grigu Exp grigu $


function vers = eegplugin_refa8import(fig,trystr,catchstr)

vers = 'refa8import1.3';
if nargin < 3,
    error('eegplugin_refa8import requires 3 arguments');
end

% add folder to path
if ~exist('eegplugin_refa8import');
    addpath(fullfile(which('eeglab'),'plugins',vers));
end

% find import data menu
menui = findobj(fig,'tag','import data');

% menu callback
icadefs;
versiontype = 1;
if exist('EEGLAB_VERSION')
    if EEGLAB_VERSION(1) == '4'
        versiontype = 0;
    end;
end;
if versiontype == 0
    com = [ trystr.no_check '[EEGTMP LASTCOM] = pop_loadrefa8;'  catchstr.new_non_empty ];
else
    com = [ trystr.no_check '[EEG LASTCOM] = pop_loadrefa8;'  catchstr.new_non_empty ];
end;
 
% create menu
uimenu(menui,'label','From QREFA (REFA8) .hdr file','callback',com,...
    'separator','on');



