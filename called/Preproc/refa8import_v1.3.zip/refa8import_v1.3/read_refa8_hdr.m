% READ_REFA8_HDR - Reads header information from an EEG file in CBS
% Refa8 Raw format.
%
% [HDR] = read_refa8_hdr( FILENAME )
%
% INPUT:
%   FILENAME   Name of the EEG header file (.hdr)
%
% OUTPUT:
%   HDR        Struct with header information, containing the fields
%      hdrfile   - [string] header filename
%      datafile  - [string] raw data filename
%      Fs        - [float] sample rate (Hz)
%      reference - [string] reference channel label(s)
%      trgchan   - [string] trigger channel label
%      channels  - [cell array] with channel information
%
% 

% (c) 2009 Maren Grigutsch, MPI CBS Leipzig
% $Id: read_refa8_hdr.m,v 1.5 2011/05/05 09:32:18 grigu Exp $

function [hdr]=read_refa8_hdr(hdrfn);

% fprintf('header file: %s\n',hdrfn);
[pname,fname,ext] = fileparts(hdrfn);
datafn = fullfile(pname,[fname '.raw']);
% fprintf('data file:   %s\n',datafn);

hdrlines={};
fid = fopen(hdrfn,'r');
while ~feof(fid),
    l = fgetl(fid);
    hdrlines{end+1,1}=l;
end
fclose(fid);

comments=[]; 
sections=[];

k=1;
while (k <= length(hdrlines)),
   l = hdrlines{k}; k = k+1;
   l = strtrim(l);
   if isempty(l),
       continue; 
   elseif strmatch(';',l)
       comments{end+1,1} = l;
   elseif strmatch('[',l)
       s=[];
       s.name = sscanf(l,'%s');
       s.comments=[];
       s.data=[];
       
       for j=k:length(hdrlines),
           l = hdrlines{j};
           l = strtrim(l);
           if isempty(l), continue;
           elseif strmatch(';',l),
              if ~isempty(regexp(l,'.*\[Record st(art|op)\]')),
                  comments{end+1,1} = l;
              else
                  s.comments{end+1,1}=l;
              end
             
           elseif strmatch('[',l),
              j=j-1; break;
           else
              s.data{end+1,1} = l;
           end
       end
       sections{end+1,1} = s;
       k=j+1; 
   end
end

clear hdrlines;

sections = cell2mat(sections);

Fs = 0;
refchan=[];
channels={};
for k=1:length(sections),
   switch (sections(k).name), 
       case '[samplerate]'
           % FIXme!
           [Fs,count,errmsg,nextindx]=sscanf(sections(k).data{1},'%f');
           if count ~= 1, error('Cannot determine sample rate.'); end
%            fprintf('sample rate: %g\n',Fs);
           
       case '[reference]'
           [refchan,count,errmsg,nextindx]=sscanf(sections(k).data{1},'%s');
           if count ~= 1, error('Cannot determine the reference channel(s).'); end
%            fprintf('reference channel: %s\n',refchan);
           
       case '[triggerchannel]'
           [trgchan,count,errmsg,nextindx]=sscanf(sections(k).data{1},'%s');
           if count ~= 1, error('Cannot determine the reference channel(s).'); end
%            fprintf('trigger channel: %s\n',trgchan);
           
       case '[channels]'
           for j=1:length(sections(k).data),
              c = regexp(sections(k).data{j},'\s*\|\s*','split');
              if length(c)>=7,
                  chan.indx = str2num(c{1});
                  chan.label = c{2};
                  chan.unit = c{3};
                  chan.sens = str2double(c{4})*str2double(c{5});
                  chan.dspchan = c{6};
                  chan.type = c{7};
                  channels{end+1} = chan;   
              end
           end
   end
end


channels = cell2mat(channels);
labels = {channels.label};
nchan = length(labels);
% Determine the number of samples from the length of the raw data file.
% Raw data are stored as 4-byte integers, big-endian (int32-be).
fid = fopen(datafn,'r');
fseek(fid,0,'eof');
flen = ftell(fid);
fclose(fid);
npnts = fix(flen/4/nchan);
if flen ~= 4*npnts*nchan,
    warning('Inconsistent file length of rawdata file.'),
end


hdr = [];
hdr.hdrfile = hdrfn;
hdr.datafile = datafn;
hdr.Fs = Fs;
hdr.nChans = nchan;
hdr.nSamples = npnts;
% FIXme: place data for different recording blocks in different trials???
hdr.nTrials = 1;
hdr.label = labels(:);

hdr.orig.hdrfile = hdrfn;
hdr.orig.datafile = datafn;
hdr.orig.Fs = Fs;
hdr.orig.nChans = nchan;
hdr.orig.nSamples = npnts;
hdr.orig.channels = channels;
hdr.orig.reference = refchan;
hdr.orig.trgchan = trgchan;
hdr.orig.comments = comments;
hdr.orig.sections = sections;


