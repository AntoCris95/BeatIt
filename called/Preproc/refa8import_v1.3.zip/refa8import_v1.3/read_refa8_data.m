% READ_REFA8_DATA import MPI CBS Refa8 RAW datasets (.raw).
%
%  DATA = read_refa8_data(HDR);
%  DATA = read_refa8_data(HDR,TRL);
%  DATA = read_refa8_data(HDR,TRL,CHANINDX);
%
%    INPUT:
%     HDR       Header struct, see READ_REFA8_HDR.
%     TRL       Matrix with trial definitions, nTrials x 3, see 
%               TRIALFUN_REFA8_RAW.
%               Use TRL=[] to read the whole data set as one single (continuous) 
%               trial.
%     CHANINDX  Vector of (1-based) indices of the channels to be loaded.
%
%    OUTPUT:
%     DATA      Data struct in Fieldtrip format

% (c) 2009 by Maren Grigutsch, MPI CBS Leipzig
% $Id: read_refa8_data.m,v 1.8 2017/08/24 13:10:13 grigu Exp grigu $


function [data] = read_refa8_data(hdr,trl,chanindx);

if ischar(hdr), hdr = read_refa8_hdr(hdr); end

if nargin<2, trl = []; end
if nargin<3, chanindx = []; end


%FIXme!
if ~isfield(hdr,'datafile') || isempty(hdr.datafile),
    error('Cannot extract the name of the data (.raw) file.');
end

[fid,msg] = fopen(hdr.datafile,'rb','ieee-le');
if fid==-1,
    error(['Couldn''t open the datafile: ' msg]);
end

if ~isfield(hdr,'orig') || isempty(hdr.orig),
    error('Missing rawdata information in the header.');
end

if isempty(chanindx), chanindx = [1:hdr.nChans]; 
elseif max(chanindx) > hdr.nChans,
    error('Requested channel index exceeds number of channels in the dataset.');
end

% origlab = {hdr.orig.channels.label};
sens = [hdr.orig.channels.sens];
sens = diag( sens(chanindx) );

dat=[]; tim=[];

if isempty(trl), trl = [1 hdr.nSamples 0]; end
if size(trl,1)==1,        % continous data
    
    trllen = trl(2)-trl(1)+1;
    fseek(fid, (trl(1)-1)*hdr.nChans*4,'bof');
    dat = zeros(length(chanindx),trllen);
    tim = ([0:trllen-1] + trl(3))/hdr.Fs; 
    chunksize=1024;
    n = 0;
    while n < trllen,
        chunksize = min(chunksize, trllen-n);
        [x,count] = fread(fid,chunksize*hdr.nChans,'int32=>int32');
        x = reshape(x,[hdr.nChans chunksize]);
        dat(:,n + [1:chunksize]) = sens * double(x(chanindx,:)); 
        n = n + chunksize;
    end
    clear x;
    dat = {dat};
    tim = {tim};
    
else                      % several (short?) trials 
    
    for k=1:size(trl,1),
        trllen = trl(k,2)-trl(k,1)+1;
        fseek(fid, (trl(k,1)-1)*hdr.nChans*4,'bof');
        x = fread(fid,trllen*hdr.nChans,'int32=>int32'); 
        % real-world scaling
        x = reshape(x,[hdr.nChans trllen]);
        dat{k} = sens * double(x(chanindx,:));
        tim{k} = ([0:trllen-1] + trl(k,3)) / hdr.Fs;  
    end

end

fclose(fid);

hdr.trl = trl;

data = [];
data.hdr = hdr;
data.trial = dat;
data.time = tim;
data.fsample = hdr.Fs;
data.label = hdr.label(chanindx);
data.sampleinfo = trl(:,1:2);
if (size(trl,1) > 1) && (size(trl,2) > 3),
    data.trialinfo = trl(:,4:end);
end    

% data.dimord = 'chan_time';


