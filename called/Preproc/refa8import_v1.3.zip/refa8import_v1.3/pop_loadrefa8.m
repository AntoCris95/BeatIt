% pop_loadrefa8() - load REFA8 raw data (QREFA MPI CBS format) and return
%                   an EEGLAB EEG struct
%
% Usage.
%  >> [EEG, com] = pop_loadrefa8;   % pop-up window mode
%  >> [EEG, com] = pop_loadrefa8(path,hdrfile);
%  >> [EEG, com] = pop_loadrefa8(path, hdrfile, timerange);
%  >> [EEG, com] = pop_loadrefa8(path, hdrfile, [], chans);
%  >> [EEG, com] = pop_loadrefa8(path, hdrfile, timerange, chans);
%
% Optional inputs:
%   path        - path to data files
%   hdrfile     - name of QREFA header file (incl. extension)
%   timerange   - [beg] first timepoint (in seconds) to read (up to end of file) 
%                   or
%                 [beg end] first and last timepoint (in seconds) to read 
%                  default: all
%   chans       - vector of channel indices to read 
%                  default: all
%
% Outputs:
%   EEG         - EEGLAB EEG structure
%   com         - history string
%
% Author: Maren Grigutsch, 2011

% Copyright (C) 2011 Maren Grigutsch, MPI CBS Leipzig
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

% $Id: pop_loadrefa8.m,v 1.3 2012/02/28 13:00:16 grigu Exp grigu $

function [EEG, com] = pop_loadrefa8(path, hdrfile, trange, chans)

com = '';
EEG = [];

if nargin<4,chans = []; chanarg=[]; end
if nargin<3, trange = []; timarg=[]; end

if nargin < 2
    [hdrfile path] = uigetfile2('*.hdr', 'Select QREFA hdr-file - pop_loadrefa8()');
    if hdrfile(1) == 0, return; end

    timarg ='[]'; trange=[]; srange=[];
    chanarg= '[]'; chans =[];

    drawnow;
    uigeom = {[1 0.5] [1 0.5]};
    uilist = {{ 'style' 'text' 'string' 'Interval ([beg end] in seconds; default: all):'} ...
              { 'style' 'edit' 'string' ''} ...
              { 'style' 'text' 'string' 'Channels (indices e.g., [1:2 4]; default: all):'} ...
              { 'style' 'edit' 'string' ''}};
    result = inputgui(uigeom, uilist, 'pophelp(''pop_loadrefa8'')', 'Load a REFA8 (QREFA MPI CBS format) dataset');
    if isempty(result), return, end
    if ~isempty(result{1}),
        timarg = result{1};
        trange = str2num(timarg);
    end
    if ~isempty(result{2}),
        chanarg =result{2};
        chans = str2num(chanarg);
    end
end

% Read the header file.
disp('pop_loadrefa8(): reading header file');
hdr = read_refa8_hdr(fullfile(path,hdrfile));

% Get the events.
[evt] = read_refa8_event(hdr);
hdr.event = evt;

% Common Infos
try
    EEG = eeg_emptyset;
catch
end
EEG.comments = ['Original file: ' hdr.hdrfile];
%hdr.commoninfos.numberofchannels = str2double(hdr.commoninfos.numberofchannels);
EEG.srate = hdr.Fs;
EEG.trials = 1;

% Channel Infos
if isempty(chans),
    chans = 1:hdr.nChans; chanarg=[];
else
    chanarg = ['[' num2str(chans(:)') ']'];
end
EEG.nbchan = length(chans);

if any(chans < 1) || any(chans > hdr.nChans)
    error('Requested channels out of available channel range');
end

% for k=1:length(chans),
%     EEG.chanlocs(k).labels = hdr.label{chans(k)};
% end

% Sample range
if isempty(trange),
    srange = [1 hdr.nSamples];
else
    timarg = ['[' num2str(trange(1)) num2str(trange(end)) ']'];
    srange = round(trange*hdr.Fs)+1;
end

if length(srange)==1, srange = [srange hdr.nSamples]; end
if ~isvector(srange) || (length(srange)~=1 && length(srange)~=2), 
    error('Illegal time range parameters.'); 
end
if length(srange)==1, srange = [srange hdr.nSamples]; end
if (srange(1) > srange(2)), 
    error('Invalid time range parameters: beg must not exceed end!');
end
if (srange(1) < 1) || (srange(2) > hdr.nSamples)
    error('Requested time range not available.');
end   
EEG.pnts = srange(2) - srange(1) + 1;



% Read the data.
data = read_refa8_data(hdr,[srange(1) srange(2) 0],chans);
EEG.data = data.trial{1};
EEG.chanlocs=[];
for k=1:length(data.label),
    EEG.chanlocs(k).labels = data.label{k};
    EEG.chanlocs(k).X = 0;
    EEG.chanlocs(k).Y = 0;
    EEG.chanlocs(k).Z = 0;
end
EEG.chanlocs = convertlocs(EEG.chanlocs, 'cart2all');
clear data;

% BUILD EEG event struct.
EEG.urevent = [];
if isempty(hdr.event),
    
    EEG.urevent=[]; 
    EEG.event=[];
    warning('No events found in the dataset.\n');
    
else
    for k=1:length(hdr.event),
       EEG.urevent(k).latency = hdr.event(k).sample;
       if strcmp('DC',hdr.event(k).type),
           EEG.urevent(k).type = 'boundary';
       elseif strcmp('SL',hdr.event(k).type),
           EEG.urevent(k).type = '_SL_';
       else
           EEG.urevent(k).type = num2str(hdr.event(k).value);
       end
       EEG.urevent(k).init_index = k;
       EEG.urevent(k).init_time = hdr.event(k).time;
    end

    uridx = find([EEG.urevent.latency]>=srange(1) & [EEG.urevent.latency]<srange(2));

    % EEG.event=[];
    % for k=1:length(uridx),
    %     EEG.event(k).latency = EEG.urevent(uridx(k)).latency - srange(1) + 1;
    %     EEG.event(k).type = EEG.urevent(uridx(k)).type;
    %     EEG.event(k).duration = 0;
    %     EEG.event(k).urevent = uridx(k);
    % end

    EEG.event = struct(...
                   'latency',num2cell([EEG.urevent(uridx).latency] - srange(1) + 1),...
                   'type',{EEG.urevent(uridx).type},...
                   'urevent', num2cell(uridx),...
                   'duration',0);

    fprintf('Found %d events.\n',length(EEG.event));

    bidx = strmatch('boundary',{EEG.event.type},'exact');
    if ~isempty(bidx),
        for k=bidx(:)',
           EEG.event(k).latency = EEG.event(k).latency - 0.5;
        end
        fprintf('Found %d boundary events.\n',length(bidx));
    end

    % Add a boundary event at the beginning of the dataset.
    firstEvent = struct(...
        'latency',0.5,...
        'type','boundary',...
        'urevent',[],...
        'duration',srange(1)-1);

    EEG.event = [firstEvent EEG.event];
    fprintf('Added boundary event at the beginning.\n');

    sidx = find(strcmp('_SL_',{EEG.event.type}));

    if ~isempty(sidx),
        warning('Found %d sample lost events (code ''_SL_'')!',length(sidx));
    end
end

EEG.ref = 'common';

try
    EEG = eeg_checkset(EEG);
catch
end

if nargout == 2
    if ~isempty(timarg),
        com = sprintf('EEG = pop_loadrefa8 (''%s'', ''%s'', %s);',path,hdrfile,timarg);
    elseif ~isempty(chanarg),
        if isempty(timarg), timarg = '[]'; end
        com = sprintf('EEG = pop_loadrefa8 (''%s'', ''%s'', %s, %s);',path,hdrfile,timarg,chanarg);
    else
        com = sprintf('EEG = pop_loadrefa8 (''%s'', ''%s'');', path, hdrfile);
    end
end





