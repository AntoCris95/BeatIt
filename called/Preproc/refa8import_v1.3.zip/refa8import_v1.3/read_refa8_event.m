% READ_REFA8_EVENT reads event information of a Refa8 Raw EEG data set 
% (MPI CBS format).
% 
%
% [EVT, HDR] = read_refa8_event( FILENAME );
%
%   FILENAME     Header filemame
%
% [EVT, HDR] = read_refa8_event( HDR );
%
%   HDR          Header info struct generated using read_reaf8_hdr()

% (c) 2009 Maren Grigutsch, MPI CBS Leipzig
% $Id: read_refa8_event.m,v 1.5 2017/07/06 17:01:40 grigu Exp grigu $

function [event,hdr] = read_refa8_event(hdr);

if ischar( hdr ),
    hdr = read_refa8_hdr( hdr );
end

if ~isstruct(hdr) || ~isfield(hdr,'orig') || isempty(hdr.orig),
    error('Cannot extract header information.');
end


if ~isfield(hdr.orig,'datafile') || isempty(hdr.orig.datafile),
    error('Cannot determine the name of the data file.');
end
datafile = hdr.orig.datafile;

trgchan = 'TRIGGER';
if isfield(hdr.orig,'trgchan') && ~isempty(hdr.orig.trgchan),
    trgchan = hdr.orig.trgchan;
end

if ~isfield(hdr.orig,'channels') || isempty(hdr.orig.channels),
    error('Missing channel information.');
end
channels = hdr.orig.channels;

trgi = strmatch(trgchan,{channels.label},'exact');
if length(trgi) ~= 1, 
    error('Missing the trigger channel.'); 
end

nChans = length(channels);

fid = fopen(datafile,'r');
if ~isfield(hdr.orig,'nSamples') || isempty(hdr.orig.nSamples),
    fseek(fid,0,'eof');
    flen = ftell(fid);
    nSamples = fix(flen/(4*nChans));
else
    nSamples = hdr.orig.nSamples;
end
fseek(fid,(trgi-1)*4,'bof');
trgval = fread(fid,nSamples,'uint32=>uint32',(nChans-1)*4);
fclose(fid);


dcmask   = uint32(hex2dec('10000'));
slmask   = uint32(hex2dec('20000'));
% skipmask = uint32(hex2dec('40000'));
trgmask  = uint32(hex2dec('000000ff'));


% register only the rising edge of a trigger pulse
%------------------------------------------------
% find doublets, i.e. triggers with identical codes in 
% neighboring samples 

% di = find(trgval(2:end)==trgval(1:end-1)) + 1;


val = bitand(trgval,trgmask);
di = find(val(2:end)==val(1:end-1)) + 1;

% remove duplicate triggers, but keep DC (discontinuity) and 
% SL (samplelost) events
if ~isempty(di),
        di = di(~bitand(trgval(di),dcmask));
        di = di(~bitand(trgval(di),slmask));
        trgval(di) = 0;
end

% demasking
%---------------------
indx = find(trgval);
if ~isempty(indx),
    dc = find(bitand(trgval(indx),dcmask)); % block markers
    sl = find(bitand(trgval(indx),slmask)); % sample lost
    sl = setdiff(sl,dc);
    val = val(indx);
end

event = struct('type','trigger',...
               'sample',num2cell(indx),...
               'value',num2cell(val),...
               'time', num2cell((indx-1)/hdr.Fs),...
               'offset',0,...
               'duration',0);
   
%                'trgval',num2cell(trgval(indx)),...
           
if ~isempty(dc),
    for k=dc(:)', event(k).type = 'DC'; end
end
if ~isempty(sl),
    for k=sl(:)', event(k).type = 'SL'; end
end

if nargout>1, hdr.event = event; end


           

    

